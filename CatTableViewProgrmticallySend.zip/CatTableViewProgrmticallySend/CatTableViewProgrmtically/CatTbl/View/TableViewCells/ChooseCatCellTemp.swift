//
//  ChooseCatCellTemp.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 23/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

class ChooseCatCellTemp: UITableViewCell {

    @IBOutlet weak var catLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    static var identifier: String {
        return String(describing: self)
    }
    
    static var nib: UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
}
