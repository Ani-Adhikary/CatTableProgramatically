//
//  CustomDropDownView.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 22/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

class CustomDropDownView: UIView {
    
    private var isForOther = false
    
    let label: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Cat"
        return label
    }()
    
    let dropDownView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    let dropDownLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Select Cat"
        return label
    }()
    
    let dropDownTextField: UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "Enter cat"
        textField.isHidden = true
        textField.autocorrectionType = .no
        return textField
    }()
    
    let dropDownLineView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    let dropDownImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: ImageConstant.downArrow)
        return imageView
    }()
    
    init(isForOther: Bool = false) {
        self.isForOther = isForOther
        super.init(frame: CGRect.zero)
        addCustomView()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addCustomView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func addCustomView() {
        addSubview(label)
        addSubview(dropDownView)
        dropDownView.addSubview(dropDownLabel)
        dropDownView.addSubview(dropDownTextField)
        dropDownView.addSubview(dropDownLineView)
        dropDownView.addSubview(dropDownImageView)
        
        dropDownView.layer.borderWidth = 1.0
        dropDownView.layer.borderColor = #colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1)
        
        NSLayoutConstraint.activate([
            topAnchor.constraint(equalTo: label.topAnchor),
            label.leadingAnchor.constraint(equalTo: leadingAnchor),
            label.trailingAnchor.constraint(equalTo: trailingAnchor),
            
            dropDownView.leadingAnchor.constraint(equalTo: label.leadingAnchor, constant: 5.0),
            dropDownView.trailingAnchor.constraint(equalTo: label.trailingAnchor, constant: 5.0),
            dropDownView.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 5.0),
            dropDownView.heightAnchor.constraint(equalToConstant: 50.0),
            
            dropDownLabel.leadingAnchor.constraint(equalTo: dropDownView.leadingAnchor, constant: 20.0),
            dropDownLabel.trailingAnchor.constraint(equalTo: dropDownLineView.leadingAnchor, constant: 20.0),
            dropDownLabel.centerYAnchor.constraint(equalTo: dropDownView.centerYAnchor),
            
            dropDownTextField.leadingAnchor.constraint(equalTo: dropDownView.leadingAnchor, constant: 20.0),
            dropDownTextField.trailingAnchor.constraint(equalTo: dropDownLineView.leadingAnchor, constant: 20.0),
            dropDownTextField.centerYAnchor.constraint(equalTo: dropDownView.centerYAnchor),
            
            dropDownLineView.widthAnchor.constraint(equalToConstant: 1.0),
            dropDownLineView.heightAnchor.constraint(equalToConstant: 22.0),
            dropDownLineView.trailingAnchor.constraint(equalTo: dropDownImageView.leadingAnchor, constant: -10.0),
            dropDownLineView.centerYAnchor.constraint(equalTo: dropDownLabel.centerYAnchor),
            
            dropDownImageView.trailingAnchor.constraint(equalTo: dropDownView.trailingAnchor, constant: -20.0),
            dropDownImageView.widthAnchor.constraint(equalToConstant: 18.0),
            dropDownImageView.centerYAnchor.constraint(equalTo: dropDownLabel.centerYAnchor),
            bottomAnchor.constraint(equalTo: dropDownView.bottomAnchor, constant: 0)
        ])
    }
}
