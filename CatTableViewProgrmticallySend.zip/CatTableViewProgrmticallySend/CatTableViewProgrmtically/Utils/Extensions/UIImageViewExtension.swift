//
//  UIImageViewExtension.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 24/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

extension UIImageView {
    
    func rotate(withAngle angle: CGFloat, animated: Bool) {
        UIView.animate(withDuration: animated ? 0.5 : 0, animations: {            
            self.transform = CGAffineTransform(rotationAngle: angle)
        })
    }
}
