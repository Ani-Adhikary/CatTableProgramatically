//
//  CatTblViewControllerExtn.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 24/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

extension CatTblViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case 0:
            return setupCatDropDownCell(tableView)
        default:
            return UITableViewCell()
        }
    }
    
    func setupCatDropDownCell(_ tableView: UITableView) -> UITableViewCell {
        let cell = CatDropDownCell(style: .default, reuseIdentifier: CatDropDownCell.identifier)
        tableViewCell = cell
        cell.delegate = self
        savedHeight = 200
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath == expandedCellIndex {
            let cell = CatDropDownCell(style: .default, reuseIdentifier: CatDropDownCell.identifier)
            
            if dateCellExpanded {
                cell.tableViewCatShowConstraint?.constant = savedHeight
                return 240
            } else {
                cell.tableViewCatShowConstraint?.constant = 0
                return 200
            }
        }
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        expandedCellIndex = indexPath
        
        if dateCellExpanded {
            dateCellExpanded = false
        } else {
            dateCellExpanded = true
        }
        tableView.beginUpdates()
        tableView.endUpdates()
    }
    
}

extension CatTblViewController: CatDropDownCellProtocol {
    func dropDownClicked() {
        print("Inside here----------")
        tableViewCell?.updateHeightConstraintForTable(tableView)
        
        //tableViewCell?.tableViewCats
        //tableView.reloadData()
        tableView.rowHeight = 900
        tableView.estimatedRowHeight = 900
        tableView.layoutSubviews()
        tableView.layoutIfNeeded()
        //tableView.he
        
        //tableView.reloadRows(at: [IndexPath], with: UITableView.RowAnimation)
    }
    
    
}
