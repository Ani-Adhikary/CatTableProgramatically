//
//  CatTblViewControllerExtn.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 24/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

extension CatTblViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case 0:
            return setupCatDropDownCell(tableView)
        default:
            return UITableViewCell()
        }
    }
    
    func setupCatDropDownCell(_ tableView: UITableView) -> UITableViewCell {
        let cell = CatDropDownCell(style: .default, reuseIdentifier: CatDropDownCell.identifier)
        return cell
    }
    
}
