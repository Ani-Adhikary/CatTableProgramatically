//
//  CatPlainViewController.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 24/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

class CatPlainViewController: UIViewController {

    var doneButtonToolBar: UIToolbar!
    private var tableViewCatShowConstraint: NSLayoutConstraint?
    private var tableViewCatHideConstraint: NSLayoutConstraint?
    private var tableViewHeight: CGFloat = 250.0
    private var cats = ["Murku", "Geru", "Piku", "Tilu"]
    
    let customCatDropDownView: CustomDropDownView = {
        let view = CustomDropDownView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    let tableViewCats: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.layer.borderWidth = 1.0
        tableView.layer.borderColor = #colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1)
        tableView.isHidden = true
        tableView.showsVerticalScrollIndicator = false
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupLayout()
        setupNavBar()
        setupTableView()
        
    }
    
    override func viewDidLayoutSubviews() {
        customCatDropDownView.dropDownView.layoutIfNeeded()
    }

    func setupNavBar() {
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationController?.topViewController?.title = "Cat Plain Heaven"
        navigationItem.hidesBackButton = true
        navigationController?.isNavigationBarHidden = false
    }
    
    func setupLayout() {
        view.backgroundColor = .white
        view.addSubview(customCatDropDownView)
        view.addSubview(tableViewCats)
        
        tableViewCatShowConstraint = tableViewCats.heightAnchor.constraint(equalToConstant: tableViewHeight)
        tableViewCatHideConstraint = tableViewCats.heightAnchor.constraint(equalToConstant: 0)
        
        NSLayoutConstraint.activate([
            customCatDropDownView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20.0),
            customCatDropDownView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20.0),
            customCatDropDownView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20.0),
            
            tableViewCats.topAnchor.constraint(equalTo: customCatDropDownView.bottomAnchor),
            tableViewCats.leadingAnchor.constraint(equalTo: customCatDropDownView.leadingAnchor),
            tableViewCats.trailingAnchor.constraint(equalTo: customCatDropDownView.trailingAnchor)
            
        ])
    }
    
    func setupTableView() {
        tableViewCats.register(ChooseCatCellTemp.nib, forCellReuseIdentifier: ChooseCatCellTemp.identifier)
        tableViewCats.dataSource = self
        tableViewCats.delegate = self
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(dropDownViewCatClicked))
        customCatDropDownView.dropDownView.addGestureRecognizer(tap)
    }
    
    @objc func dropDownViewCatClicked() {
        animateTableView(isHidden: !tableViewCats.isHidden, tableViewCats, customCatDropDownView.dropDownImageView)
    }
    
    func animateTableView(isHidden: Bool, _ tableView: UITableView, _ imageView: UIImageView) {
        UIView.animate(withDuration: 0.3, delay: 0.03, animations: {
            if isHidden {
                tableView.alpha = 0
            } else {
                tableView.alpha = 1
            }
            tableView.isHidden = isHidden
            self.updateHeightConstraintForTable(tableView)
        })
        
        UIView.animate(withDuration: 0.3, animations: {
            if isHidden {
                imageView.rotate(withAngle: CGFloat(0), animated: false)
            } else {
                imageView.rotate(withAngle: CGFloat(Double.pi), animated: false)
            }
        })
    }
    
    func updateHeightConstraintForTable(_ tableView: UITableView) {
        
        if tableView.isHidden {
            tableViewCatShowConstraint?.isActive = false
            tableViewCatHideConstraint?.isActive = true
        } else {
            tableViewCatShowConstraint?.isActive = true
            tableViewCatHideConstraint?.isActive = false
        }
        
        tableView.layoutIfNeeded()
    }
}

extension CatPlainViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cats.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: ChooseCatCellTemp.identifier, for: indexPath) as! ChooseCatCellTemp
        let catVal = cats[indexPath.row]
        cell.catLabel.text = catVal
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        customCatDropDownView.dropDownLabel.text = cats[indexPath.row]
         animateTableView(isHidden: !tableViewCats.isHidden, tableViewCats, customCatDropDownView.dropDownImageView)
        updateHeightConstraintForTable(tableView)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    
}
