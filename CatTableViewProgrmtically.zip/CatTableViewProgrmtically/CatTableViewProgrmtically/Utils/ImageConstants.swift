//
//  ImageConstants.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 22/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import Foundation

struct ImageConstant {
    
    static let downArrow = "DownArrow"
    static let upArrow = "UpArrow"
}
