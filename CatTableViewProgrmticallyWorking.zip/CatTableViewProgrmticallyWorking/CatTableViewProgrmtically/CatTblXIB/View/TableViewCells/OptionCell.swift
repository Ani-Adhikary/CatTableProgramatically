//
//  OptionCell.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 23/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

class OptionCell: UITableViewCell {

    @IBOutlet weak var optionCell: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    static var nib: UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
    
    static var identifier: String {
        return String(describing: self)
    }

    func setupData(cat: Cat) {
        optionCell.text = cat.name
    }
    
}
