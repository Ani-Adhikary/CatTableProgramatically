//
//  DropDownTableViewCell.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 23/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

class DropDownTableViewCell: UITableViewCell {

    var tableView = UITableView()
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    static var identifier: String {
        return String(describing: self)
    }

}

//extension DropDownTableViewCell: UITableViewDataSource, UITableViewDelegate {
//    
//}
