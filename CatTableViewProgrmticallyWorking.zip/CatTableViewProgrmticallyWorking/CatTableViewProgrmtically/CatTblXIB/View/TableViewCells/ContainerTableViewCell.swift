//
//  ContainerTableViewCell.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 23/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

class ContainerTableViewCell: UITableViewCell {
    
    @IBOutlet weak var selectLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    var cats: [Cat] = []
    
    override func awakeFromNib() {
        super.awakeFromNib()
        cats = CatResponse.getCats2()
        setupTableView()
        
    }
    
    func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(OptionCell.nib, forCellReuseIdentifier: OptionCell.identifier)
        tableView.tableFooterView = UIView()
        tableView.estimatedRowHeight = 44
        tableView.rowHeight = UITableView.automaticDimension
    }
    
    static var nib: UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
    
    static var identifier: String {
        return String(describing: self)
    }
        
}

extension ContainerTableViewCell: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("cats count----- \(cats.count)")
        return cats.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: OptionCell.identifier, for: indexPath) as! OptionCell
        print("[Row]------- \([indexPath.row])")
        print("cats val----- \(cats[indexPath.row])")
        //cell.optionCell.text = cats[indexPath.row]
        let catVal = cats[indexPath.row]
        cell.setupData(cat: catVal)
        //cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("\(cats[indexPath.row])")
    }
    
    
}
