//
//  CatResponse.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 23/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import Foundation

class CatResponse {
    
    
    static func getCats() -> [String] {
        return ["Murku", "Tilu", "Piku", "Geru"]
    }
    
    static func getCats2() -> [Cat] {
        return [
            Cat(name: "Geru"),
            Cat(name: "Geru"),
            Cat(name: "Tilu"),
            Cat(name: "Piku")
        ]
    }
}

struct Cat {
    var name: String
}
