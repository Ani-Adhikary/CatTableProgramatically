//
//  CatTableViewCell.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 23/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

class CatTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    static var identifier: String {
        return String(describing: self)
    }
}
