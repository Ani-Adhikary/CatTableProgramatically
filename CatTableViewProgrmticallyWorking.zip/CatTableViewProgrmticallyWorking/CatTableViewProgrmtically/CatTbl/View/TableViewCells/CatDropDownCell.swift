//
//  CatDropDownCell.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 22/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

class CatDropDownCell: UITableViewCell {
    
    private var tableViewCatShowConstraint: NSLayoutConstraint?
    private var tableViewCatHideConstraint: NSLayoutConstraint?
    private var tableViewHeight: CGFloat = 250.0
    private var catList = ["Murku", "Geru", "Piku", "Tilu"]
    
    let customCatDropDownView: CustomDropDownView = {
        let view = CustomDropDownView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    let tableViewCats: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.layer.borderWidth = 1.0
        tableView.layer.borderColor = #colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1)
        tableView.isHidden = true
        tableView.allowsSelection = true
        tableView.setNeedsFocusUpdate()
        tableView.showsVerticalScrollIndicator = false
        return tableView
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    static var identifier: String {
        return String(describing: self)
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupLayout() {
        addSubview(tableViewCats)
        addSubview(customCatDropDownView)
        
        selectionStyle = .none
        
        tableViewCats.register(ChooseCatCellTemp.nib, forCellReuseIdentifier: ChooseCatCellTemp.identifier)
        tableViewCats.dataSource = self
        tableViewCats.delegate = self
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(dropDownViewCatClicked))
        customCatDropDownView.dropDownView.addGestureRecognizer(tap)
        tap.cancelsTouchesInView = false
        tableViewCatShowConstraint = tableViewCats.heightAnchor.constraint(equalToConstant: tableViewHeight)
        tableViewCatHideConstraint = tableViewCats.heightAnchor.constraint(equalToConstant: 0)
        
        separatorInset = UIEdgeInsets.init(top: 0, left: -20, bottom: 0, right: 0)
        
        NSLayoutConstraint.activate([
            customCatDropDownView.topAnchor.constraint(equalTo: topAnchor, constant: 20.0),
            customCatDropDownView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20.0),
            customCatDropDownView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20.0),
            
            tableViewCats.topAnchor.constraint(equalTo: customCatDropDownView.bottomAnchor),
            tableViewCats.leadingAnchor.constraint(equalTo: customCatDropDownView.leadingAnchor),
            tableViewCats.trailingAnchor.constraint(equalTo: customCatDropDownView.trailingAnchor),
            bottomAnchor.constraint(equalTo: customCatDropDownView.bottomAnchor, constant: 10.0)
            
        ])
        
    }
    
    @objc func dropDownViewCatClicked() {
        animateTableView(isHidden: !tableViewCats.isHidden, tableViewCats, customCatDropDownView.dropDownImageView)
    }
    
    func animateTableView(isHidden: Bool, _ tableView: UITableView, _ imageView: UIImageView) {
        UIView.animate(withDuration: 0.3, delay: 0.03, animations: {
            if isHidden {
                tableView.alpha = 0
            } else {
                tableView.alpha = 1
            }
            tableView.isHidden = isHidden
            self.updateHeightConstraintForTable(tableView)
        })
        
        UIView.animate(withDuration: 0.3, animations: {
            if isHidden {
                imageView.rotate(withAngle: CGFloat(0), animated: false)
            } else {
                imageView.rotate(withAngle: CGFloat(Double.pi), animated: false)
            }
        })
    }
    
    func updateHeightConstraintForTable(_ tableView: UITableView) {
        
        if tableView.isHidden {
            tableViewCatShowConstraint?.isActive = false
            tableViewCatHideConstraint?.isActive = true
        } else {
            tableViewCatShowConstraint?.isActive = true
            tableViewCatHideConstraint?.isActive = false
        }
        
        tableView.layoutIfNeeded()
    }
    
}

extension CatDropDownCell: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return catList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: ChooseCatCellTemp.identifier, for: indexPath) as! ChooseCatCellTemp
        let catVal = catList[indexPath.row]
        cell.catLabel.text = catVal
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Selected")
    }
}
