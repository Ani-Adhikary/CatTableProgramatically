//
//  DropDownCell.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 26/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

class DropDownCell: UITableViewCell {
    
    @IBOutlet weak var btnDrop: UIButton!
    @IBOutlet weak var tblView: UITableView!
    
    var fruitList = ["Orange", "Banana", "Apple", "Blueberry", "Mango", "Cherry", "Grape", "Strawberry"]
        
    override func awakeFromNib() {
        super.awakeFromNib()
        tblView.isHidden = true
        tblView.delegate = self
        tblView.dataSource = self
        
        tblView.register(ChooseCatCellTemp.nib, forCellReuseIdentifier: ChooseCatCellTemp.identifier)
    }
    
    static var nib: UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
    
    static var identifier: String {
        return String(describing: self)
    }
    
    @IBAction func onClickDropButton(_ sender: Any) {
        if tblView.isHidden {
            animate(toogle: true, type: btnDrop)
        } else {
            animate(toogle: false, type: btnDrop)
        }
    }
    
    func animate(toogle: Bool, type: UIButton) {
        
        if type == btnDrop {
            
            if toogle {
                UIView.animate(withDuration: 0.3) {
                    self.tblView.isHidden = false
                }
            } else {
                UIView.animate(withDuration: 0.3) {
                    self.tblView.isHidden = true
                }
            }
        } else {
            if toogle {
                UIView.animate(withDuration: 0.3) {
                    //self.lbl.isHidden = false
                }
            } else {
                UIView.animate(withDuration: 0.3) {
                    //self.lbl.isHidden = true
                }
            }
        }
    }
    
}

extension DropDownCell: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fruitList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        /*let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = fruitList[indexPath.row]
        return cell
        */
        
        let cell = tableView.dequeueReusableCell(withIdentifier: ChooseCatCellTemp.identifier, for: indexPath) as! ChooseCatCellTemp
        let catVal = fruitList[indexPath.row]
        cell.catLabel.text = catVal
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        btnDrop.setTitle("\(fruitList[indexPath.row])", for: .normal)
        animate(toogle: false, type: btnDrop)
    }
    
    
}
