//
//  CatTblWithDropDownXIBVC.swift
//  CatTableViewProgrmtically
//
//  Created by Ani Adhikary on 26/05/20.
//  Copyright © 2020 Ani Adhikary. All rights reserved.
//

import UIKit

class CatTblWithDropDownXIBVC: UIViewController {
    
    private var doneButtonToolBar: UIToolbar!
    
    var dropDownCell: CatDropDownCell?
    
    let tableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.showsVerticalScrollIndicator = false
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //view.backgroundColor = #colorLiteral(red: 0.8078343393, green: 0.985483706, blue: 0.6176425044, alpha: 1)
        setupTableView()
        setupLayout()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupNavBar()
        //setupTableView()
    }
    
    override func viewDidLayoutSubviews() {
        //customCatDropDownView.dropDownView.layoutIfNeeded()
        dropDownCell?.customCatDropDownView.dropDownView.layoutIfNeeded()
    }
    
    func setupNavBar() {
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationController?.topViewController?.title = "Cat Heaven"
        navigationItem.hidesBackButton = true
        navigationController?.isNavigationBarHidden = false
    }
    
    private func setupLayout() {
        view.addSubview(tableView)
        view.backgroundColor = .white
        var constraints = [
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ]
        
        if #available(iOS 11.0, *) {
            constraints.append(contentsOf: [
                tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
                tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
            ])
        } else {
            constraints.append(contentsOf: [
                tableView.topAnchor.constraint(equalTo: view.topAnchor),
                tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
            ])
        }
        NSLayoutConstraint.activate(constraints)
    }
    
    private func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.sectionFooterHeight = 0.0
        tableView.separatorStyle = .none
        tableView.register(CatDropDownCell.self, forCellReuseIdentifier: CatDropDownCell.identifier)
        
        tableView.register(DropDownCell.nib, forCellReuseIdentifier: DropDownCell.identifier)
    }
    
}


extension CatTblWithDropDownXIBVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case 0:
            //return setupCatDropDownCell(tableView)
            
            let dropCell = tableView.dequeueReusableCell(withIdentifier: DropDownCell.identifier, for: indexPath) as! DropDownCell
            return dropCell
        default:
            return UITableViewCell()
        }
    }
    
    func setupCatDropDownCell(_ tableView: UITableView) -> UITableViewCell {
        let cell = CatDropDownCell(style: .default, reuseIdentifier: CatDropDownCell.identifier)
        dropDownCell = cell
        view.bringSubviewToFront(cell.tableViewCats)
        return cell
    }
    
    func setupDropCell(_ tableView: UITableView) -> UITableViewCell {
        let cell = DropDownCell(style: .default, reuseIdentifier: DropDownCell.identifier)
        return cell
    }
    
//    func setupCell() {
//        let quoteCell = tableView.dequeueReusableCell(withIdentifier: DropDownCell.identifier, for: indexPath) as! DropDownCell
//        return quoteCell
//    }
    
}
